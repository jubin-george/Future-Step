package com.example.android.testapplication;


import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Main7Activity extends AppCompatActivity {
    EditText editText,editText2;
    Button button;
    StringRequest stringRequest;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main7);
        editText=(EditText)findViewById(R.id.uname);
        editText2=(EditText)findViewById(R.id.pass);
        button=(Button)findViewById(R.id.bt);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loginFn();
            }
            private void loginFn() {
                // Toast.makeText(getApplicationContext(),"Sucess",Toast.LENGTH_LONG).show();
                final String URL = "http://192.168.6.129/jubin/select.php";


                stringRequest = new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {

                    @Override
                    public void onResponse(String response) {
                        try{

                            JSONObject jsonObject=new JSONObject(response);
                            String sucess=jsonObject.getString("sucess");
                            JSONArray jsonArray=jsonObject.getJSONArray("login");
                            if(sucess.equals("1")){
                                for(int i=0;i<jsonArray.length();i++){
                                    JSONObject obj=jsonArray.getJSONObject(i);
                                    String uname=obj.getString("uname").trim();
                                    String pword=obj.getString("pword").trim();

                                    //list.add(uname);

                                    Toast.makeText(getApplicationContext(), "Sucess \n"+uname, Toast.LENGTH_LONG).show();

                                    Intent intent=new Intent(Main7Activity.this,Main5Activity.class);
                                    intent.putExtra("username",uname);
                                    startActivity(intent);



                                }

                            }
                            else
                            {
                                Toast.makeText(getApplicationContext(), "Ivalid Details ! ", Toast.LENGTH_LONG).show();
                            }


                        }
                        catch(JSONException e){
                            e.printStackTrace();
                            Toast.makeText(getApplicationContext(), "Login Failed", Toast.LENGTH_LONG).show();
                        }
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getApplicationContext(), "no", Toast.LENGTH_LONG).show();
                        Toast.makeText(getApplicationContext(), "failed" + error, Toast.LENGTH_LONG).show();
                    }
                }) {

                    protected Map<String, String> getParams() throws AuthFailureError {
                        Map<String, String> Params = new HashMap<>();
                        Params.put("username", editText.getText().toString());
                        Params.put("password", editText2.getText().toString());
                        return Params;
                    }


                };

                RequestQueue requestQueue= Volley.newRequestQueue(Main7Activity.this);
                requestQueue.add(stringRequest);
            }

        });

    }
}
