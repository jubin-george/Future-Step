package com.example.android.testapplication;

import android.support.v7.app.AppCompatActivity;
import android.app.AlertDialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Button;
import android.widget.Toast;
import android.database.sqlite.SQLiteDatabase;


public class Main2Activity extends AppCompatActivity {
    EditText name, email, phone;
    Button btn;
    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);


        name = (EditText) findViewById(R.id.name);
        email = (EditText) findViewById(R.id.email);
        phone = (EditText) findViewById(R.id.phone);
        btn = (Button) findViewById(R.id.button);
        db = openOrCreateDatabase("StudentDB", Context.MODE_PRIVATE, null);
        if (db != null) {
            Toast.makeText(this, "Ctreated", Toast.LENGTH_SHORT).show();
        }
        db.execSQL("CREATE TABLE IF NOT EXISTS employee(name VARCHAR,email VARCHAR,phone VARCHAR);");
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (name.getText().toString().trim().length() == 0 ||
                        email.getText().toString().trim().length() == 0 ||
                        phone.getText().toString().trim().length() == 0) {
                    showMessage("Error", "Please enter all values");
                    return;
                }
                db.execSQL("INSERT INTO employee VALUES('" + name.getText() + "','" + email.getText() +
                        "','" + phone.getText() + "');");
                showMessage("Success", "Record added");
                clearText();
            }
        });
    }
    public void showMessage(String title, String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }

    public void clearText() {
        name.setText("");
        email.setText("");
        phone.setText("");
        name.requestFocus();
    }
}
